# sort_files - Automatic File Sorting Tool

A lightweight command-line utility that automatically organizes and moves files inside a specified folder or drive into subfolders based on file extension, modification date, or filename keywords.

This distribution package includes both the standalone Windows executable (`sort_files.exe`) and the Python source code (`sort_files.py`).

## Key Features

* **Safe Preview Mode (Dry Run by Default)**
  Unless the `--apply` flag is specified, no files are actually moved. The tool simply prints `[DRY-RUN]` previews showing where each file would go.

* **Duplicate File Protection**
  If a file with the same name already exists in the destination folder, it is automatically renamed with a sequential suffix (e.g., `file_1.mp4`, `file_2.mp4`) to prevent accidental overwriting.

* **Three Sorting Modes (`--mode`)**
  1. `ext` (Default): Sorts files by extension (e.g., `mp4`, `png`, `txt`; files without an extension go into `no_extension`).
  2. `date`: Sorts files by last modified date (defaults to `YYYY-MM` format).
  3. `name`: Sorts files based on keywords found in the filename (unmatched files go into `other`).

## Usage (Windows / Command Prompt)

Open Command Prompt or PowerShell, navigate to the folder containing `sort_files.exe`, and run the commands below.

*Note: If you prefer running the Python script directly, replace `sort_files.exe` with `python sort_files.py`.*

### 1. Preview Changes First (Dry Run)

Displays the planned file moves without modifying anything on your disk:

```cmd
sort_files.exe "F:\\"
```

### 2. Actually Move Files (`--apply`)

Once you have verified the dry-run output, add `--apply` to execute the moves:

```cmd
sort_files.exe "F:\\" --apply
```

### 3. Include Subfolders Recursively (`--recursive`)

Sorts files inside all nested subfolders as well:

```cmd
sort_files.exe "F:\\" --recursive --apply
```

### 4. Sort by Modification Date (`--mode date`)

```cmd
# Sort by Year-Month (e.g., 2026-11)
sort_files.exe "F:\\" --mode date --apply

# Sort by Year-Month-Day (e.g., 2026-11-24)
sort_files.exe "F:\\" --mode date --date-format "%Y-%m-%d" --apply
```

### 5. Sort by Filename Keywords (`--mode name`)

Specify rules in `KEYWORD:FOLDER` format (can be specified multiple times):

```cmd
sort_files.exe "F:\\" --mode name --name-rule video:Videos --name-rule capture:Captures --apply
```

## Command-Line Options

| Option | Description |
| :--- | :--- |
| `target_dir` | Path to the target folder or drive to organize (Required) |
| `--mode {ext,date,name}` | Sorting criteria (`ext`, `date`, or `name`; default: `ext`) |
| `--date-format FORMAT` | Folder naming format when using `--mode date` (default: `%Y-%m`) |
| `--name-rule KEYWORD:FOLDER` | Keyword-to-folder mapping for `--mode name` (repeatable) |
| `--recursive` | Recursively include files in subdirectories |
| `--apply` | Execute file moves (dry-run preview only if omitted) |
| `-h`, `--help` | Show help message and exit |

## Package Contents

* `sort_files.exe`: Standalone Windows executable (no Python installation required)
* `sort_files.py`: Source code compatible with Python 3.10+ (uses standard library only)
* `README.md`: Documentation (Japanese)
* `README_en.md`: Documentation (English)

## Important Notes & Disclaimer

* **Specifying Drive Roots on Windows**: In Windows Command Prompt, writing `"F:\"` causes the trailing `\"` to be interpreted as an escaped quote. Always use double backslashes like `"F:\\"` or omit quotes (`F:\`).
* **Avoid System Directories**: Do not run this tool on system-managed folders such as `C:\Windows` or `Program Files`, as moving system files can break your OS or applications. Use it only on personal data folders or external drives.
* **Disclaimer**: The author is not responsible for any data loss or unintended file organization resulting from the use of this tool. Always back up important data or test with a dry run before applying changes.